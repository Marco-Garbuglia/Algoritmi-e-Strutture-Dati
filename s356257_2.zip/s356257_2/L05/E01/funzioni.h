#ifndef FUNZIONI_H
#define FUNZIONI_H

typedef struct {
    int s;
    int f;
} att;

int leggi(att v[], int max);
void attSel(int n, att v[]);

#endif